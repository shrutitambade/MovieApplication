package com.example.admin.movieapplcation;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.example.admin.movieapplcation.Activities.AboutUs;
import com.example.admin.movieapplcation.Activities.MovieDetailActivity;
import com.example.admin.movieapplcation.Adapter.MovieArrayAdapter;
import com.example.admin.movieapplcation.Model.MovieDetails;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener {
    ListView list;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.about_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.action_aboutus:
                Intent i=new Intent( getApplicationContext(), AboutUs.class );
                startActivity( i );
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );
        setTitle( "Upcomimg Movies" );
        list=findViewById( R.id.list );
        list.setOnItemClickListener( this );

        checkConnection();
    }

    private void checkConnection() {
        if(isOnline()){
            new CheckConnectionStatus().execute(  "http://api.themoviedb.org/3/movie/upcoming?api_key=b7cd3340a794e5a2f35e3abb820b497f" );

            Toast.makeText(MainActivity.this, "You are connected to Internet", Toast.LENGTH_SHORT).show();

        }else{

            Toast.makeText(MainActivity.this, "You are not connected to Internet", Toast.LENGTH_SHORT).show();

        }
    }

    private boolean isOnline() {
        ConnectivityManager cm = (ConnectivityManager)getSystemService( Context.CONNECTIVITY_SERVICE);

        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        if (netInfo != null && netInfo.isConnectedOrConnecting()) {

            return true;

        } else {

            return false;

        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent i=new Intent(this, MovieDetailActivity.class);
        i.putExtra( "MOVIE_DETAILS",(MovieDetails)parent.getItemAtPosition( position ) );
        startActivity( i);
    }

    class CheckConnectionStatus extends AsyncTask<String,Void,String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {
            URL url=null;
            try{
                url=new URL( strings[0] );

            }catch (MalformedURLException e)
            {
                e.printStackTrace();
            }
            try{
                HttpURLConnection httpURLConnection= (HttpURLConnection) url.openConnection();
                InputStream inputStream=httpURLConnection.getInputStream();
                BufferedReader bufferedReader=new BufferedReader(new InputStreamReader( inputStream ) );
                String s=bufferedReader.readLine();
                bufferedReader.close();
                return s;
            }catch (Exception e){
                Log.e("Error:",e.getMessage(),e);
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            super.onPostExecute( s );

            JSONObject jsonObject;
            try
            {
                jsonObject=new JSONObject( s );
                ArrayList<MovieDetails> movieList=new ArrayList<>(  );
                JSONArray jsonArray=jsonObject.getJSONArray( "results" );

                for(int i=0;i<jsonArray.length();i++){
                    JSONObject object=jsonArray.getJSONObject( i );
                    MovieDetails movieDetails=new MovieDetails();
                    movieDetails.setTitle( object.getString( "title" ));
                    movieDetails.setRelease_date( object.getString( "release_date" ) );
                    movieDetails.setPoster_path( object.getString( "poster_path" ) );
                    movieDetails.setOverview( object.getString( "overview" ) );
                    movieDetails.setVote_average( object.getInt( "vote_average" ) );

                    if(!object.getBoolean("adult"))
                    {
                        movieDetails.setAdult("(U/A)");
                    }
                    else
                    {
                        movieDetails.setAdult("(A)");
                    }

                    movieList.add( movieDetails );
                }

                MovieArrayAdapter movieArrayAdapter=new MovieArrayAdapter( getApplicationContext(),R.layout.movies_list,movieList );
                list.setAdapter( movieArrayAdapter );
            }catch (JSONException e){
                e.printStackTrace();
            }
        }


    }
}

package com.example.admin.movieapplcation.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.borjabravo.readmoretextview.ReadMoreTextView;
import com.bumptech.glide.Glide;
import com.example.admin.movieapplcation.Model.MovieDetails;
import com.example.admin.movieapplcation.R;


public class MovieDetailActivity extends AppCompatActivity {

    ImageView image2;
    TextView mTitle;
    ReadMoreTextView mOverview;
    RatingBar ratingBar;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate( R.menu.about_menu, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.action_aboutus:
                Intent i=new Intent( getApplicationContext(), AboutUs.class );
                startActivity( i );
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_movie_detail );

        setTitle("Movie Details");
        image2=findViewById( R.id.image2 );
        mTitle=findViewById( R.id.mTitle );
        mOverview=findViewById( R.id.mOverview );
        ratingBar=findViewById( R.id.ratingBar );
        ratingBar.getResources().getColor( R.color.accent );
        final MovieDetails details1= (MovieDetails) getIntent().getExtras().getSerializable( "MOVIE_DETAILS" );

        if(details1!=null)
        {
            Glide.with( this ).load( "https://image.tmdb.org/t/p/w342/" + details1.getPoster_path() ).into( image2 );
            mTitle.setText( details1.getTitle() );
            mOverview.setText( details1.getOverview() );

            ratingBar.setRating( details1.getVote_average()/5.5F );


        }

    }
}

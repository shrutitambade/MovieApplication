package com.example.admin.movieapplcation.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.admin.movieapplcation.Model.MovieDetails;
import com.example.admin.movieapplcation.R;


import java.util.List;

/**
 * Created by admin on 22-10-2018.
 */

public class MovieArrayAdapter extends ArrayAdapter {
    private List<MovieDetails> movieDetailsList;
    private int resource;
    private Context context;

    public MovieArrayAdapter(@NonNull Context context, int resource, @NonNull List<MovieDetails> movieDetailsList) {
        super( context, resource, movieDetailsList );

        this.context = context;
        this.resource = resource;
        this.movieDetailsList = movieDetailsList;

    }



    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        MovieDetails details = movieDetailsList.get( position );
        View view = LayoutInflater.from( context ).inflate( resource, parent, false );
        TextView movieName = view.findViewById( R.id.movieName );
        TextView relDate = view.findViewById( R.id.relDate );
        TextView ua = view.findViewById( R.id.ua );
        ImageView image1 = view.findViewById( R.id.image1 );


        movieName.setText( details.getTitle() );
        relDate.setText( details.getRelease_date() );
ua.setText( details.getAdult() );
        Glide.with( context ).load( "https://image.tmdb.org/t/p/w342/" + details.getPoster_path() ).into( image1 );
        return view;
    }

    @Nullable
    @Override
    public Object getItem(int position) {
        return movieDetailsList.get( position );
    }
}

